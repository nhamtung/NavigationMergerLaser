^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package laser_scan_sparsifier
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.2 (2016-03-19)
------------------

0.3.1 (2015-12-18)
------------------

0.3.0 (2015-11-10)
------------------

0.2.1 (2015-10-14)
------------------
* [sys] Catkinizing: laser_scan_sparsifier
* [sys] renamed skip to step parameter in scan sparsifier
* Contributors: Ivan Dryanovski, Miguel Sarabia
